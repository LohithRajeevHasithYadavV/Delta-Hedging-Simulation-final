"""Delta hedging simulation package."""
